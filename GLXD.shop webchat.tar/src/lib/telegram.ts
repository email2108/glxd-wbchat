import { db } from '@/lib/db'

export interface TelegramMessage {
  chat_id: string
  text: string
  parse_mode?: 'HTML' | 'Markdown'
}

export class TelegramService {
  private botToken: string
  private apiUrl: string

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || ''
    this.apiUrl = `https://api.telegram.org/bot${this.botToken}`
  }

  async sendMessage(message: TelegramMessage): Promise<boolean> {
    try {
      if (!this.botToken) {
        throw new Error('Telegram bot token not configured')
      }

      const response = await fetch(`${this.apiUrl}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(message),
      })

      const data = await response.json()

      if (!data.ok) {
        throw new Error(`Telegram API error: ${data.description}`)
      }

      return true
    } catch (error) {
      console.error('Error sending Telegram message:', error)
      return false
    }
  }

  async sendOTP(chatId: string, otp: string): Promise<boolean> {
    const message = {
      chat_id: chatId,
      text: `🔐 *Mã OTP của bạn*\n\nMã xác thực GLXD của bạn là: *${otp}*\n\n⏰ Mã có hiệu lực trong 5 phút\n\n🛡️ Vui lòng không chia sẻ mã này với bất kỳ ai!`,
      parse_mode: 'Markdown' as const,
    }

    return this.sendMessage(message)
  }

  async sendAdminNotification(message: string): Promise<boolean> {
    const adminChatId = process.env.TELEGRAM_ADMIN_CHAT_ID
    if (!adminChatId || adminChatId === 'your_admin_chat_id_here') {
      console.warn('Admin chat ID not configured')
      return false
    }

    const adminMessage = {
      chat_id: adminChatId,
      text: `🚨 *Thông báo Hệ thống GLXD*\n\n${message}`,
      parse_mode: 'Markdown' as const,
    }

    return this.sendMessage(adminMessage)
  }

  async verifyWebhook(update: any): Promise<boolean> {
    try {
      // Verify the update is from Telegram
      if (!update.message || !update.message.chat || !update.message.chat.id) {
        return false
      }

      const chatId = update.message.chat.id.toString()
      const text = update.message.text

      // Handle OTP verification
      if (text && /^\d{6}$/.test(text)) {
        const otp = text
        
        // Find the OTP record
        const otpRecord = await db.oTP.findFirst({
          where: {
            code: otp,
            sentTo: chatId,
            type: 'TELEGRAM',
            used: false,
            expiresAt: {
              gt: new Date(),
            },
          },
          include: {
            user: true,
          },
        })

        if (otpRecord) {
          // Mark OTP as used
          await db.oTP.update({
            where: { id: otpRecord.id },
            data: { used: true },
          })

          // Send confirmation message
          await this.sendMessage({
            chat_id: chatId,
            text: '✅ *Xác thực thành công!*\n\nMã GLXD OTP của bạn đã được xác thực. Bạn có thể tiếp tục sử dụng dịch vụ.',
            parse_mode: 'Markdown',
          })

          // Notify admin
          await this.sendAdminNotification(
            `Người dùng ${otpRecord.user.name || 'Unknown'} đã xác thực OTP thành công qua Telegram.`
          )

          return true
        } else {
          await this.sendMessage({
            chat_id: chatId,
            text: '❌ *Mã GLXD OTP không hợp lệ hoặc đã hết hạn!*\n\nVui lòng yêu cầu mã OTP mới.',
            parse_mode: 'Markdown',
          })
        }
      }

      // Handle OTP request - only respond to "otp glxd.shop"
      if (text && text.toLowerCase() === 'otp glxd.shop') {
        // Extract user info from Telegram message
        const telegramUser = update.message.from;
        const username = telegramUser.username || null;
        
        // Check if user exists, if not create one
        let user = await db.user.findFirst({
          where: { telegramChatId: chatId }
        })

        if (!user) {
          user = await db.user.create({
            data: {
              telegramChatId: chatId,
              name: telegramUser.first_name || `User_${chatId}`,
              username: username,
            }
          })
        } else {
          // Update user info if changed
          const updateData: any = {};
          if (username && user.username !== username) {
            updateData.username = username;
          }
          if (telegramUser.first_name && user.name !== telegramUser.first_name) {
            updateData.name = telegramUser.first_name;
          }
          
          if (Object.keys(updateData).length > 0) {
            user = await db.user.update({
              where: { id: user.id },
              data: updateData
            });
          }
        }

        // Generate OTP
        const otp = Math.floor(100000 + Math.random() * 900000).toString()
        const expiresAt = new Date(Date.now() + 5 * 60 * 1000) // 5 minutes

        // Save OTP to database
        await db.oTP.create({
          data: {
            code: otp,
            type: 'TELEGRAM',
            sentTo: chatId,
            userId: user.id,
            expiresAt,
          }
        })

        // Send OTP to user with clear message
        await this.sendMessage({
          chat_id: chatId,
          text: `👋 Xin chào ${telegramUser.first_name || 'bạn'}!\n\n🔐 *Mã GLXD OTP của bạn*: ${otp}\n\n⏰ Mã có hiệu lực trong 5 phút\n\n🛡️ Bot chỉ phản hồi khi bạn nhắn tin, không tự gửi cho bất kỳ ai.\n\n🌐 Vui lòng nhập mã này tại: http://localhost:3000`,
          parse_mode: 'Markdown',
        })

        // Notify admin
        await this.sendAdminNotification(
          `📨 ${user.name || user.id} (@${username || 'no_username'}) đã yêu cầu OTP từ ${chatId}`
        )

        return true
      }

      // Handle other messages - send help message
      if (text && text.toLowerCase() !== 'otp glxd.shop') {
        await this.sendMessage({
          chat_id: chatId,
          text: `👋 Xin chào ${update.message.from.first_name || 'bạn'}!\n\n🤖 Để nhận mã OTP GLXD, vui lòng gửi tin nhắn chính xác:\n\n*otp glxd.shop*\n\n💡 Bot chỉ phản hồi khi bạn yêu cầu OTP, không tự gửi tin nhắn cho bất kỳ ai.`,
          parse_mode: 'Markdown',
        })
        return true
      }

      return true
    } catch (error) {
      console.error('Error verifying webhook:', error)
      return false
    }
  }
}

export const telegramService = new TelegramService()